"""Convergent validity against dwell time (Appendix A).
Spearman correlation between full-coverage S_cov and reported dwell time for
the ten real-world incidents with a reported dwell time. "Same day" is coded
as 0 months. Expected: rho = 0.61, p = 0.06, n = 10."""
import csv, os
from scipy.stats import spearmanr

rows = list(csv.DictReader(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "dwell_time.csv"))))
rows = [r for r in rows if r["Dwell months (numeric)"].strip()]
s = [float(r["S_cov full coverage (%)"]) for r in rows]
d = [float(r["Dwell months (numeric)"]) for r in rows]
rho, p = spearmanr(s, d)
print(f"n={len(rows)}  Spearman rho={rho:.2f}  p={p:.2f}")
