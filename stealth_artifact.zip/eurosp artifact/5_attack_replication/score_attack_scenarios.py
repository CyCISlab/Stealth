"""Replication on ATT&CK for ICS scenarios (Section 5.9, Table 6).

Scores every software, campaign, and group object in ATT&CK for ICS v20.1
with at least three non-Impact techniques. Techniques use the validated
v17.1 mapping (1_core_pipeline). The nine sub-techniques added after v17.1
are mapped with the same rules: their targeted assets come from the v20.1
STIX, and their data components (all already in the validated v17.1 map)
come from v20.1 detection strategies and analytics. Four asset types new
in v20.1 were dual-coded (new_asset_types_dimension.csv, 4 of 4 agreement).
Scoring is identical to score_incidents.py (same M1-M4 ladder).

Outputs: attack_scenarios_scored.csv, attack_scenarios_unscored.csv
Prints: means, sign test, bootstrap 95% CI (20,000 resamples, seed 42),
and the mean gap on the scenarios with no curated-corpus overlap.
"""
import csv, json, os, random, statistics, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
import pandas as pd  # noqa: E402
from score_incidents import act, det, PROFILES, r1  # noqa: E402
act, det = dict(act), dict(det)

CORE = os.path.join(HERE, "..", "1_core_pipeline")
asset_dim = dict(pd.read_csv(os.path.join(CORE, "2_asset_purdue_dimension.csv"))[["asset_name", "dimension"]].values)
asset_dim.update(dict(pd.read_csv(os.path.join(HERE, "new_asset_types_dimension.csv"))[["asset_name", "dimension"]].values))
comp_full = {}
for _, r in pd.read_csv(os.path.join(CORE, "3_script3_technique_datasource_map.csv")).dropna(subset=["Full Component"]).iterrows():
    comp_full[str(r["Full Component"]).split(": ", 1)[-1]] = (str(r["Full Component"]), str(r["Dimension"]))

# ATT&CK objects that name an event in the curated corpus, or the malware or
# actor behind one (marked with a dagger in Table 6).
OVERLAP = {"C0020", "C0025", "C0028", "C0030", "C0031", "C0034", "S0603", "S1009",
           "S1165", "G1027", "G0034", "S0604", "S1072", "S0089", "S0607"}

objs = json.load(open(os.path.join(HERE, "ics-attack-20.1.json")))["objects"]
live = lambda o: not o.get("revoked") and not o.get("x_mitre_deprecated")
eid = lambda o: [r["external_id"] for r in o.get("external_references", [])
                 if r.get("source_name", "").startswith("mitre")][0]
tech = {o["id"]: o for o in objs if o["type"] == "attack-pattern" and live(o)}
srcs = {o["id"]: o for o in objs if o["type"] in ("malware", "campaign", "intrusion-set") and live(o)}

# Map techniques added after v17.1 with the same closed rules.
by = {o["id"]: o for o in objs}
rels = [r for r in objs if r["type"] == "relationship" and live(r)]
added = []
for tid_obj, t in tech.items():
    tid = eid(t)
    if tid in act:
        continue
    assets = [by[r["target_ref"]]["name"] for r in rels
              if r["relationship_type"] == "targets" and r["source_ref"] == tid_obj]
    comps = set()
    for r in rels:
        if r["relationship_type"] == "detects" and r["target_ref"] == tid_obj:
            for aref in by[r["source_ref"]].get("x_mitre_analytic_refs", []):
                an = by.get(aref)
                if an and live(an):
                    for ls in an.get("x_mitre_log_source_references", []):
                        dc = by.get(ls["x_mitre_data_component_ref"])
                        if dc and dc["name"] in comp_full:
                            comps.add(dc["name"])
    dims = {asset_dim[a] for a in assets if a in asset_dim}
    if dims:
        act[tid] = dims
        det[tid] = {comp_full[c][0]: comp_full[c][1] for c in comps}
        added.append(tid)

def s_cov(T, M):
    g = a = 0
    for t in T:
        D = {d for c, d in det.get(t, {}).items() if c in M}
        g += len(act[t] - D); a += len(act[t])
    return 100 * g / a if a else 0.0

uses = {}
for r in objs:
    if r["type"] != "relationship" or r.get("relationship_type") != "uses" or not live(r):
        continue
    s, t = srcs.get(r["source_ref"]), tech.get(r["target_ref"])
    if not s or not t:
        continue
    if any(p["phase_name"] == "impact" for p in t.get("kill_chain_phases", [])):
        continue
    uses.setdefault(r["source_ref"], set()).add(eid(t))

scored, unscored = [], []
for sid, T in uses.items():
    o = srcs[sid]
    mapped = {t for t in T if act.get(t)}
    kind = {"malware": "S", "campaign": "C", "intrusion-set": "G"}[o["type"]]
    if len(mapped) >= 3:
        it, full = r1(s_cov(mapped, PROFILES[0])), r1(s_cov(mapped, PROFILES[3]))
        scored.append([eid(o), o["name"], kind, len(mapped), it, full, r1(it - full),
                       "yes" if eid(o) in OVERLAP else "no"])
    elif len(T) >= 3:
        unscored.append([eid(o), o["name"], kind, len(T), len(mapped),
                         " ".join(sorted(T - mapped))])

scored.sort(key=lambda r: -r[6])
with open(os.path.join(HERE, "attack_scenarios_scored.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ATT&CK ID", "Name", "Type", "Mapped non-Impact techniques",
                "IT-only (M1)", "Full (M4)", "Gap", "Overlaps curated corpus"])
    w.writerows(scored)
with open(os.path.join(HERE, "attack_scenarios_unscored.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ATT&CK ID", "Name", "Type", "Non-Impact techniques", "Mapped",
                "Unmapped (post-v17.1) techniques"])
    w.writerows(unscored)

gaps = [r[6] for r in scored]
print(f"scored n={len(scored)}  IT-only={r1(statistics.mean(r[4] for r in scored))}  "
      f"full={r1(statistics.mean(r[5] for r in scored))}  gap={r1(statistics.mean(gaps))}  "
      f"range {min(gaps)}-{max(gaps)}  positive={sum(g > 0 for g in gaps)}")
nonzero = [g for g in gaps if g != 0]
print(f"negative gaps: {sum(g < 0 for g in gaps)}  zero gaps: {sum(g == 0 for g in gaps)}")
print(f"sign test one-sided p (zeros excluded) = {0.5 ** len(nonzero):.2e}")
rng = random.Random(42)
boot = sorted(statistics.mean(rng.choices(gaps, k=len(gaps))) for _ in range(20000))
print(f"bootstrap 95% CI of mean gap: [{r1(boot[500])}, {r1(boot[19499])}]")
no = [r[6] for r in scored if r[7] == "no"]
print(f"no corpus overlap n={len(no)}  mean gap={r1(statistics.mean(no))}  positive={sum(g > 0 for g in no)}")
print(f"techniques mapped beyond v17.1: {sorted(added)}")
print(f"unscored: {[r[0] for r in unscored]}")
