"""Replication on ATT&CK for ICS scenarios (Section 5.9, Table 6).

Scores every software, campaign, and group object in ATT&CK for ICS v20.1
with at least three non-Impact techniques covered by the validated v17.1
technique mapping (1_core_pipeline). Objects that meet the threshold only
through sub-techniques added after v17.1 are listed as unscored.
Scoring is identical to score_incidents.py (same maps, same M1-M4 ladder).

Outputs: attack_scenarios_scored.csv, attack_scenarios_unscored.csv
Prints: means, sign test, bootstrap 95% CI (20,000 resamples, seed 42),
and the mean gap on the scenarios with no curated-corpus overlap.
"""
import csv, json, os, random, statistics, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from score_incidents import act, gap, s_cov, PROFILES, r1  # noqa: E402

# ATT&CK objects that name an event in the curated corpus, or the malware or
# actor behind one (marked with a dagger in Table 6).
OVERLAP = {"C0020", "C0025", "C0028", "C0030", "S0603", "S1009", "S1165",
           "G1027", "S0604", "S1072", "S0089", "S0607"}

objs = json.load(open(os.path.join(HERE, "ics-attack-20.1.json")))["objects"]
live = lambda o: not o.get("revoked") and not o.get("x_mitre_deprecated")
eid = lambda o: [r["external_id"] for r in o.get("external_references", [])
                 if r.get("source_name", "").startswith("mitre")][0]
tech = {o["id"]: o for o in objs if o["type"] == "attack-pattern" and live(o)}
srcs = {o["id"]: o for o in objs if o["type"] in ("malware", "campaign", "intrusion-set") and live(o)}

uses = {}
for r in objs:
    if r["type"] != "relationship" or r.get("relationship_type") != "uses" or not live(r):
        continue
    s, t = srcs.get(r["source_ref"]), tech.get(r["target_ref"])
    if not s or not t:
        continue
    if any(p["phase_name"] == "impact" for p in t.get("kill_chain_phases", [])):
        continue
    uses.setdefault(r["source_ref"], set()).add(eid(t))

scored, unscored = [], []
for sid, T in uses.items():
    o = srcs[sid]
    mapped = {t for t in T if act.get(t)}
    kind = {"malware": "S", "campaign": "C", "intrusion-set": "G"}[o["type"]]
    if len(mapped) >= 3:
        it, full = r1(s_cov(mapped, PROFILES[0])), r1(s_cov(mapped, PROFILES[3]))
        scored.append([eid(o), o["name"], kind, len(mapped), it, full, r1(it - full),
                       "yes" if eid(o) in OVERLAP else "no"])
    elif len(T) >= 3:
        unscored.append([eid(o), o["name"], kind, len(T), len(mapped),
                         " ".join(sorted(T - mapped))])

scored.sort(key=lambda r: -r[6])
with open(os.path.join(HERE, "attack_scenarios_scored.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ATT&CK ID", "Name", "Type", "Mapped non-Impact techniques",
                "IT-only (M1)", "Full (M4)", "Gap", "Overlaps curated corpus"])
    w.writerows(scored)
with open(os.path.join(HERE, "attack_scenarios_unscored.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ATT&CK ID", "Name", "Type", "Non-Impact techniques", "Mapped",
                "Unmapped (post-v17.1) techniques"])
    w.writerows(unscored)

gaps = [r[6] for r in scored]
print(f"scored n={len(scored)}  IT-only={r1(statistics.mean(r[4] for r in scored))}  "
      f"full={r1(statistics.mean(r[5] for r in scored))}  gap={r1(statistics.mean(gaps))}  "
      f"range {min(gaps)}-{max(gaps)}  positive={sum(g > 0 for g in gaps)}")
print(f"sign test one-sided p = {0.5 ** len(gaps):.2e}")
rng = random.Random(42)
boot = sorted(statistics.mean(rng.choices(gaps, k=len(gaps))) for _ in range(20000))
print(f"bootstrap 95% CI of mean gap: [{r1(boot[500])}, {r1(boot[19499])}]")
no = [r[6] for r in scored if r[7] == "no"]
print(f"no corpus overlap n={len(no)}  mean gap={r1(statistics.mean(no))}  positive={sum(g > 0 for g in no)}")
print(f"unscored (post-v17.1 sub-techniques): {[r[0] for r in unscored]}")
