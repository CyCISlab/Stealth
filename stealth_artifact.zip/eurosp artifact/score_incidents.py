"""Score any incident file with the paper's validated mapping and M1-M4 ladder.

Usage:  python3 score_incidents.py <incidents.json> <output.csv>

Uses the per-technique activity map (2_script2_technique_asset_map.csv) and
detection map (3_script3_technique_datasource_map.csv) from 1_core_pipeline,
and the same cumulative component ladder as 7_script7deploymentprofile.py.
Impact-tactic techniques have no activity set and never contribute.
Used for the held-out validation (Section 5.8, Table 5).
"""
import csv, json, os, statistics, sys
from decimal import Decimal, ROUND_HALF_UP

def r1(x):
    """Round half up to one decimal, as in the paper tables."""
    return float(Decimal(str(x)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
CORE = os.path.join(HERE, "1_core_pipeline")
df_act = pd.read_csv(os.path.join(CORE, "2_script2_technique_asset_map.csv"))
df_det = pd.read_csv(os.path.join(CORE, "3_script3_technique_datasource_map.csv"))

act = {}
for _, r in df_act.iterrows():
    t = str(r["Technique ID"]).strip().upper()
    act.setdefault(t, set())
    if pd.notna(r["Dimension"]) and str(r["Dimension"]).strip():
        act[t].add(str(r["Dimension"]).strip())
det, comp_dim = {}, {}
for _, r in df_det.iterrows():
    if pd.isna(r["Full Component"]) or not str(r["Full Component"]).strip():
        continue
    t = str(r["Technique ID"]).strip().upper()
    c, d = str(r["Full Component"]).strip(), str(r["Dimension"]).strip()
    det.setdefault(t, {})[c] = d
    comp_dim[c] = d

LADDER_ADD = [
 {"Command: Command Execution","File: File Access","File: File Creation","File: File Deletion","File: File Metadata","File: File Modification","Module: Module Load","Network Share: Network Share Access","Network Traffic: Network Connection Creation","Network Traffic: Network Traffic Content","Network Traffic: Network Traffic Flow","Process: OS API Execution","Process: Process Creation","Process: Process Metadata","Process: Process Termination","Scheduled Job: Scheduled Job Creation","Scheduled Job: Scheduled Job Modification","Script: Script Execution","User Account: User Account Authentication","Windows Registry: Windows Registry Key Deletion","Windows Registry: Windows Registry Key Modification"},
 {"Logon Session: Logon Session Creation","Logon Session: Logon Session Metadata","Drive: Drive Creation","Service: Service Creation","Service: Service Metadata","Service: Service Modification"},
 {"Application Log: Application Log Content","Asset: Asset Inventory","Asset: Software","Operational Databases: Process History/Live Data","Operational Databases: Process/Event Alarm"},
 {"Firmware: Firmware Modification","Operational Databases: Device Alarm"},
]
PROFILES, run = [], set()
for add in LADDER_ADD:
    run |= add
    PROFILES.append(set(run))

def gap(t, M):
    D = {d for c, d in det.get(t, {}).items() if c in M}
    return act[t] - D

def s_cov(T, M):
    g = sum(len(gap(t, M)) for t in T); a = sum(len(act[t]) for t in T)
    return 100 * g / a if a else 0.0

def main(src, out):
    incidents = json.load(open(src))
    rows = []
    for inc in incidents:
        T = sorted({x["external_id"].strip().upper() for x in inc["techniques"]
                    if act.get(x["external_id"].strip().upper())})
        m = [r1(s_cov(T, M)) for M in PROFILES]
        dom = sum(1 for t in T if gap(t, PROFILES[3])) / len(T) if T else 0
        rows.append([inc["name"], len(T)] + m + [r1(m[0] - m[3]), round(dom, 3)])
    rows.sort(key=lambda r: -r[5])
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Incident", "|T|", "M1", "M2", "M3", "M4", "Gap M1-M4", "Dominance"])
        for r in rows:
            w.writerow(r)
        w.writerow(["Mean (of table values)", ""] + [r1(statistics.mean(r[i] for r in rows)) for i in range(2, 7)] + [""])
    for r in rows: print(r)
    print("mean M1..M4, gap:", [r1(statistics.mean(r[i] for r in rows)) for i in range(2, 7)])

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
