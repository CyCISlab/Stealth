# Artefact: SoK: Classifying Stealth in ICS Attacks and Measuring Its Visibility Gap

This artefact reproduces every number in the paper's evaluation. All inputs
are public: the MITRE ATT&CK for ICS STIX bundles and public incident
reports. No data needs redaction.

## Quick start

```
pip install -r requirements.txt     # pandas, numpy, scipy (openpyxl optional)
./run_all.sh                        # about 5 minutes; robustness checks take most of it
```

Python 3.9 or later. Every script writes its outputs next to itself, and the
committed outputs are the ones `run_all.sh` regenerates.

## Layout and where each result appears in the paper

| Folder | What it contains | Paper |
|---|---|---|
| `1_core_pipeline/` | The scoring framework and the 13-incident corpus (scripts 1 to 12, run in order) | Sections 4, 5.1 to 5.5, Tables 3 and 4, Appendices A to F |
| `2_heldout_validation/` | The six held-out incidents and their scores | Section 5.8, Table 5 |
| `3_robustness/` | Mapping perturbation, dimensional collapse, null baselines, restricted corpus, known groups | Sections 5.6 and 5.7 |
| `4_per_stage/` | Stealth profile by ATT&CK tactic | Section 3, "Stealth across attack stages" |
| `5_attack_replication/` | Replication on every scorable ATT&CK for ICS v20.1 object (23) | Section 5.9, Table 6 |
| `6_coding_reliability/` | Blind dual coding of asset dimensions and Impact severity, with Cohen's kappa | Section 4.3 |
| `7_dwell_time/` | Convergent-validity check against reported dwell time | Appendix A |
| `score_incidents.py` | Scores any incident file with the validated mapping and the M1 to M4 ladder | used by folders 2 and 5 |

## 1. Core pipeline (`1_core_pipeline/`)

| Script | Input | Output | Role |
|---|---|---|---|
| `1_script1tactictechnique.py` | `ics-attack-17.1.json` | `1_script1_tactical_framework.csv` | 12 tactics, 83 techniques |
| `2_script2assetspurdue.py` | STIX | `2_listassets.csv`, `2_asset_purdue_dimension.csv`, `2_script2_technique_asset_map.csv` | Activity set A_t: asset, Purdue level, dimension |
| `3_script3detectiondatasoruces.py` | STIX | `3_listdata_sources.csv`, `3_datasource_dimension.csv`, `3_script3_technique_datasource_map.csv` | Detection set D_t: data components and dimension |
| `4_script4coring.py` | outputs of 2 and 3 | `4_script4technique_stealth_categorical.csv` | Gap G_t = A_t minus D_t per technique |
| `5_script5incidentscore.py` | 4 and `ics-incidents-13.json` | `5_incident_base_score.csv` | S_cov per incident (Definition 3) |
| `6_script6impactweight.py` | 5 | `6_incident_stealth_score.csv` | I_tech bands, Stealth Score S, Stealth Dominance (Table 3) |
| `7_script7deploymentprofile.py` | 2, 3, incidents | `7_ladder_summary.csv`, `7_ladder_by_incident.csv` | M1 to M4 ladder (Table 4), 42.2-point gap |
| `8_script8validation.py` | 4, incidents | `8_incident_validation.csv` | Leave-one-out stability and low-confidence flags (Appendix D) |
| `9_script9bootstrap.py` | 7 | `9_bootstrap_ci.csv`, `9_bootstrap_gains.csv` | 95% CI [34.2, 50.3] for the IT-only gain |
| `9b_script9b_bootstrap_steps.py` | 7 | `9b_bootstrap_steps.csv` | CI for each ladder step (Section 5.5) |
| `11_script11impactweight.py` | 5, `11_incident_impact_indicators.csv`, incidents | `11_impact_table.csv`, `11_impact_sweep.csv`, `11_impact_ranks.csv` | I_phys from o, d, c; x and weight sweeps (Appendix F) |
| `12_script12stealthbyprofile.py` | 6, 7 | `12_stealth_score_by_profile.csv` | Stealth Score under each profile |

The only hand-set inputs are the asset-to-dimension and data-source-to-dimension
assignments inside scripts 2 and 3, the incident technique mappings in
`ics-incidents-13.json`, and the o, d, c indicators in
`11_incident_impact_indicators.csv`. Each incident mapping lists the
sources used.

## 2. Held-out validation (`2_heldout_validation/`)

`ics-incidents-heldout-6.json` holds the six incidents mapped and scored
after the framework was frozen. `score_incidents.py` scores them with the
unchanged mapping and ladder and writes `heldout_scores.csv`
(mean IT-only 71.3, full 30.0, gain 41.3; Table 5).

## 3. Robustness (`3_robustness/`)

* `robustness_checks.py`: label-flip perturbation (2,000 trials per rate),
  alternative dimensional collapses, the full null baseline (5,000
  relabelings, p = 0.0002), and the one-sided nulls (activity side p = 0.004,
  detection side p < 0.001). Seeded, so `robustness_output.txt` is reproduced
  exactly.
* `corpus_checks.py`: restricted corpus (gain 40.6 on six high-confidence
  incidents) and known-groups validation (U = 9, one-sided p = 0.05).

## 4. Per-stage profile (`4_per_stage/`)

`per_stage_stealth.py` pools the full-coverage gap of every ATT&CK for ICS
v17.1 technique by tactic.

## 5. ATT&CK replication (`5_attack_replication/`)

`score_attack_scenarios.py` reads `ics-attack-20.1.json` and scores every
software, campaign, and group object with at least three non-Impact
techniques covered by the v17.1 mapping. Outputs:

* `attack_scenarios_scored.csv`: the 23 scenarios of Table 6, with the
  corpus-overlap flag (mean gap 27.6, 28.9 on the 11 without overlap,
  bootstrap 95% CI [22.8, 32.8]).
* `attack_scenarios_unscored.csv`: the five objects that meet the threshold
  only through sub-techniques added after v17.1, with those sub-techniques
  listed.

## 6. Coding reliability (`6_coding_reliability/`)

`dimension_severity_reliability.xlsx` holds both coders' blind assignments
for the 14 asset types and the 12 Impact techniques, the comparison, and
Cohen's kappa (0.89 and 0.88). The incident-level dual coding of technique
mappings (84.6% agreement) and its two disagreements are reported in the
paper (Table 2).

## 7. Dwell time (`7_dwell_time/`)

`dwell_time.csv` lists reported dwell times. `dwell_time_validity.py` gives
Spearman rho = 0.61 (p = 0.06, n = 10).

## Versions

The technique mapping uses ATT&CK for ICS v17.1 throughout. The replication
in folder 5 takes its scenario objects from release v20.1 and scores them
through the same v17.1 mapping, as stated in Section 5.9.
