"""Stealth profile across the kill chain (Section 3, "Stealth across attack stages").

Pools the full-coverage (M4 = C) coverage gap of every ATT&CK for ICS v17.1
technique by its tactic (STIX kill-chain phase), using the per-technique
table written by 4_script4coring.py. Impact-tactic techniques have an empty
activity set and are excluded. A technique listed under several tactics
counts once in each.
Output: per_stage_stealth.csv
"""
import collections, csv, json, os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
CORE = os.path.join(HERE, "..", "1_core_pipeline")
t4 = pd.read_csv(os.path.join(CORE, "4_script4technique_stealth_categorical.csv")).set_index("Technique ID")
objs = json.load(open(os.path.join(CORE, "ics-attack-17.1.json")))["objects"]

phases = {}
for o in objs:
    if o["type"] != "attack-pattern" or o.get("revoked") or o.get("x_mitre_deprecated"):
        continue
    tid = [r["external_id"] for r in o["external_references"] if r.get("source_name") == "mitre-attack"][0]
    phases[tid] = [p["phase_name"] for p in o.get("kill_chain_phases", [])]

gap, act, n = collections.Counter(), collections.Counter(), collections.Counter()
for tid, r in t4.iterrows():
    if r["Activity Size"] == 0:
        continue
    for p in phases.get(tid) or ["(unmapped)"]:
        gap[p] += r["Gap Size"]; act[p] += r["Activity Size"]; n[p] += 1

rows = sorted(((p, round(100 * gap[p] / act[p], 1), n[p]) for p in act), key=lambda x: -x[1])
with open(os.path.join(HERE, "per_stage_stealth.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["tactic", "coverage_stealth_pct", "n_techniques"]); w.writerows(rows)
for r in rows: print(r)
