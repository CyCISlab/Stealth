#!/usr/bin/env bash
# Re-runs every analysis in the paper from the raw inputs. Python 3.9+.
set -e
cd "$(dirname "$0")"
cd 1_core_pipeline
for s in 1_script1tactictechnique 2_script2assetspurdue 3_script3detectiondatasoruces \
         4_script4coring 5_script5incidentscore 6_script6impactweight \
         7_script7deploymentprofile 8_script8validation 9_script9bootstrap 9b_script9b_bootstrap_steps \
         11_script11impactweight 12_script12stealthbyprofile; do
  echo "== $s"; python3 "$s.py"
done
cd ..
echo "== held-out validation (Table 5)"
python3 score_incidents.py 2_heldout_validation/ics-incidents-heldout-6.json 2_heldout_validation/heldout_scores.csv
echo "== robustness checks (Section 5.6), takes a few minutes"
python3 3_robustness/robustness_checks.py | tee 3_robustness/robustness_output.txt
echo "== restricted corpus and known groups (Sections 5.6-5.7)"
python3 3_robustness/corpus_checks.py
echo "== per-stage profile (Section 3)"
python3 4_per_stage/per_stage_stealth.py
echo "== ATT&CK replication (Section 5.9, Table 6)"
python3 5_attack_replication/score_attack_scenarios.py
echo "== dwell-time validity (Appendix A)"
python3 7_dwell_time/dwell_time_validity.py
