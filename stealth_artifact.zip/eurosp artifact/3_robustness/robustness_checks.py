#!/usr/bin/env python3
"""B6 mapping-perturbation, B7 collapse sensitivity, B8 null baseline.
Faithful to 7_script7deploymentprofile.py. Reads the authors' maps; the
ladder component sets (M1..M4) are fixed by NAME, so relabeling dimensions
never changes which components a profile owns, only the dimensions they cover.
"""
import json, random, statistics, sys
import pandas as pd
from pathlib import Path

D = Path(__file__).resolve().parent.parent / "1_core_pipeline"
df_act = pd.read_csv(D / "2_script2_technique_asset_map.csv")
df_det = pd.read_csv(D / "3_script3_technique_datasource_map.csv")
incidents = json.load(open(D / "ics-incidents-13.json"))

LADDER_M1 = {  # 21 Cyber/IT components (fixed by name)
 "Command: Command Execution","File: File Access","File: File Creation",
 "File: File Deletion","File: File Metadata","File: File Modification",
 "Module: Module Load","Network Share: Network Share Access",
 "Network Traffic: Network Connection Creation","Network Traffic: Network Traffic Content",
 "Network Traffic: Network Traffic Flow","Process: OS API Execution",
 "Process: Process Creation","Process: Process Metadata","Process: Process Termination",
 "Scheduled Job: Scheduled Job Creation","Scheduled Job: Scheduled Job Modification",
 "Script: Script Execution","User Account: User Account Authentication",
 "Windows Registry: Windows Registry Key Deletion",
 "Windows Registry: Windows Registry Key Modification"}

DIMS = ["Cyber", "Operational", "Physical"]

# --- base maps -------------------------------------------------------------
# asset-type -> dimension (14 types); technique -> list of (asset,dim) rows
asset_dim0 = {}
for _, r in df_act.dropna(subset=["Dimension"]).iterrows():
    asset_dim0[str(r["Asset Name"]).strip()] = str(r["Dimension"]).strip()
tech_assets = {}   # tid -> list of asset names (keep multiplicity across rows)
for _, r in df_act.iterrows():
    if pd.isna(r["Dimension"]) or not str(r["Dimension"]).strip():
        continue
    tid = str(r["Technique ID"]).strip().upper()
    tech_assets.setdefault(tid, []).append(str(r["Asset Name"]).strip())

comp_dim0, detect_comps = {}, {}   # comp->dim ; tid->set(comp)
for _, r in df_det.iterrows():
    if pd.isna(r["Full Component"]) or not str(r["Full Component"]).strip():
        continue
    tid = str(r["Technique ID"]).strip().upper()
    comp = str(r["Full Component"]).strip()
    comp_dim0[comp] = str(r["Dimension"]).strip()
    detect_comps.setdefault(tid, set()).add(comp)
ALL = set(comp_dim0)


def gap(asset_dim, comp_dim, collapse=None):
    """Corpus-mean (M1 minus full) under given dimension maps.
    collapse: optional dict remapping a base dim to a merged label, applied
    to BOTH activity and detection dims consistently."""
    def cx(d): return collapse[d] if collapse else d
    def score(inc, M):
        gt = at = 0
        for t in inc.get("techniques", []):
            tid = str(t.get("external_id", "")).strip().upper()
            A = {cx(asset_dim[a]) for a in tech_assets.get(tid, []) if a in asset_dim}
            if not A:
                continue
            Dd = {cx(comp_dim[c]) for c in detect_comps.get(tid, set()) if c in M}
            gt += len(A - Dd); at += len(A)
        return gt / at * 100 if at else 0.0
    m1 = statistics.mean(score(i, LADDER_M1) for i in incidents)
    m4 = statistics.mean(score(i, ALL) for i in incidents)
    return m1 - m4, m1, m4


base_gap, base_m1, base_m4 = gap(asset_dim0, comp_dim0)
print(f"BASELINE: IT-only={base_m1:.1f}  full={base_m4:.1f}  gap={base_gap:.1f}pp\n")

rng = random.Random(42)
def perturb(d0, rate):
    out = {}
    for k, v in d0.items():
        if rng.random() < rate:
            out[k] = rng.choice([x for x in DIMS if x != v])
        else:
            out[k] = v
    return out

# --- B6: controlled mapping perturbation ----------------------------------
print("=== B6  Mapping-perturbation robustness (flip a fraction of the")
print("        14 asset-type and 34 component dimension labels) ===")
print(f"{'flip rate':>9} | {'mean gap':>8} {'sd':>5} | {'5th':>5} {'95th':>6} | {'<baseline?':>10}")
N = 2000
for rate in (0.05, 0.10, 0.20, 0.30):
    gs = []
    for _ in range(N):
        a = perturb(asset_dim0, rate); c = perturb(comp_dim0, rate)
        gs.append(gap(a, c)[0])
    gs.sort()
    print(f"{rate:9.0%} | {statistics.mean(gs):8.1f} {statistics.pstdev(gs):5.1f} |"
          f" {gs[int(.05*N)]:5.1f} {gs[int(.95*N)]:6.1f} | still positive: {all(g>0 for g in gs)}")

# --- B7: dimensional-collapse sensitivity ---------------------------------
print("\n=== B7  Sensitivity to the dimensional collapse ===")
collapses = {
 "Published 3-way (C / O / P)": None,
 "2-way IT vs OT (O,P merged)": {"Cyber":"IT","Operational":"OT","Physical":"OT"},
 "Operational grouped with IT": {"Cyber":"IT+","Operational":"IT+","Physical":"OT"},
 "Operational grouped with OT": {"Cyber":"IT","Operational":"OT-","Physical":"OT-"},
}
# per-incident full-coverage score for ranking stability
def full_scores(asset_dim, comp_dim, collapse):
    def cx(d): return collapse[d] if collapse else d
    out = {}
    for inc in incidents:
        gt = at = 0
        for t in inc.get("techniques", []):
            tid = str(t.get("external_id","")).strip().upper()
            A = {cx(asset_dim[a]) for a in tech_assets.get(tid,[]) if a in asset_dim}
            if not A: continue
            Dd = {cx(comp_dim[c]) for c in detect_comps.get(tid,set()) if c in ALL}
            gt += len(A-Dd); at += len(A)
        out[inc.get("name","?")] = gt/at*100 if at else 0.0
    return out

ref_rank = full_scores(asset_dim0, comp_dim0, None)
import math
def spearman(a, b):
    ks = list(a); n = len(ks)
    ra = {k:i for i,k in enumerate(sorted(ks, key=lambda k:a[k]))}
    rb = {k:i for i,k in enumerate(sorted(ks, key=lambda k:b[k]))}
    d2 = sum((ra[k]-rb[k])**2 for k in ks)
    return 1 - 6*d2/(n*(n*n-1))

print(f"{'collapse':<30} | {'gap(pp)':>7} | {'rank rho vs published':>22}")
for name, col in collapses.items():
    g = gap(asset_dim0, comp_dim0, col)[0]
    rho = spearman(ref_rank, full_scores(asset_dim0, comp_dim0, col))
    print(f"{name:<30} | {g:7.1f} | {rho:22.3f}")
print("NOTE: finer 5-level Purdue not computable; ATT&CK data components carry")
print("no Purdue level, only a dimension (this is WHY the paper collapses to 3).")

# --- B8: null baseline ------------------------------------------
print("\n=== B8  NULL BASELINE (Section 5.6, null-mapping baseline) ===")
def shuffle_map(d0):
    vals = list(d0.values()); rng.shuffle(vals)
    return dict(zip(d0.keys(), vals))
N8 = 5000
gs = []
for _ in range(N8):
    gs.append(gap(shuffle_map(asset_dim0), shuffle_map(comp_dim0))[0])
gs.sort()
mu = statistics.mean(gs); sd = statistics.pstdev(gs)
above = sum(1 for g in gs if g >= base_gap) / N8
print(f"null gap distribution over {N8} random relabelings:")
print(f"  mean={mu:.1f}  sd={sd:.1f}  5th={gs[int(.05*N8)]:.1f}  "
      f"50th={gs[N8//2]:.1f}  95th={gs[int(.95*N8)]:.1f}  max={gs[-1]:.1f}")
print(f"  real gap = {base_gap:.1f}pp")
print(f"  fraction of null >= real gap (empirical p): {above:.4f}")
z = (base_gap - mu)/sd if sd else float('inf')
print(f"  z vs null = {z:.1f}")
print("  VERDICT:", "real gap clearly separates from null (favorable)"
      if above < 0.05 else "null also yields large gaps")

# --- B8b: one-sided nulls (permute only the activity side or only the detection side)
print("\n=== B8b ONE-SIDED NULLS ===")
for label, fn in (("activity side only", lambda: gap(shuffle_map(asset_dim0), comp_dim0)[0]),
                  ("detection side only", lambda: gap(asset_dim0, shuffle_map(comp_dim0))[0])):
    g2 = [fn() for _ in range(N8)]
    p2 = sum(1 for g in g2 if g >= base_gap) / N8
    print(f"  {label:<20}: null mean={statistics.mean(g2):.1f}  empirical p={p2:.4f}")
