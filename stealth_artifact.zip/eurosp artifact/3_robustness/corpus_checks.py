"""Restricted-corpus check (Section 5.6) and known-groups validation (Section 5.7).
Reads 1_core_pipeline/7_ladder_by_incident.csv."""
import os, statistics
import pandas as pd
from scipy.stats import mannwhitneyu

HERE = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(HERE, "..", "1_core_pipeline", "7_ladder_by_incident.csv")).set_index("Incident")

# Six real-world, high-confidence incidents (no testbeds, no low-confidence scores).
HIGH = ["Stuxnet", "Triton Safety Instrumented System Attack", "2015 Ukraine Electric Power Attack",
        "2016 Ukraine Electric Power Attack", "2022 Ukraine Electric Power Attack", "Maroochy Water Breach"]
sub = df.loc[HIGH]
m1, m4 = sub["M1"].mean(), sub["M4"].mean()
print(f"Restricted corpus (n=6): M1={m1:.1f}  M4={m4:.1f}  IT-only gain={m1 - m4:.1f}")
print(sub["M4"].sort_values(ascending=False).to_string())

# Known groups, labelled from threat-intelligence reputation, not from S_cov.
STEALTHY = ["Stuxnet", "Triton Safety Instrumented System Attack", "2016 Ukraine Electric Power Attack"]
OVERT = ["FrostyGoop Incident", "Dallas Emergency Siren Attack (2017)", "Unitronics Defacement Campaign"]
a, b = df.loc[STEALTHY, "M4"], df.loc[OVERT, "M4"]
u, p = mannwhitneyu(a, b, alternative="greater")
print(f"\nKnown groups: stealthy mean={a.mean():.1f}  overt mean={b.mean():.1f}  U={u:.0f}  one-sided p={p:.2f}")
