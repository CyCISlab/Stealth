import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd

# Bootstrap CI for each adjacent rung of the M1-M4 ladder (Section 5.5).
# Same procedure as 9_script9bootstrap.py: 10,000 resamples of the 13
# incidents with replacement, seed 42, 2.5th and 97.5th percentiles.
B = 10000
SEED = 42

df = pd.read_csv('7_ladder_by_incident.csv')
rows = []
for a, b in [('M1', 'M2'), ('M2', 'M3'), ('M3', 'M4')]:
    x = (df[a] - df[b]).round(1).to_numpy(dtype=float)
    rng = np.random.default_rng(SEED)
    bm = np.array([rng.choice(x, size=len(x), replace=True).mean() for _ in range(B)])
    lo, hi = np.percentile(bm, [2.5, 97.5])
    rows.append({'Step': f'{a} to {b}', 'Mean Gain': round(x.mean(), 1),
                 'CI Low': round(lo, 1), 'CI High': round(hi, 1),
                 'Resamples': B, 'Seed': SEED})
out = pd.DataFrame(rows)
out.to_csv('9b_bootstrap_steps.csv', index=False)
print(out.to_string(index=False))
